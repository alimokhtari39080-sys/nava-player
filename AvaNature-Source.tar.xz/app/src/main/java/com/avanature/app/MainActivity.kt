package com.avanature.app

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccessTime
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.roundToInt

private val Night = Color(0xFF081A20)
private val DeepGreen = Color(0xFF103138)
private val Panel = Color(0xFF132B31)
private val PanelActive = Color(0xFF1C4140)
private val Mint = Color(0xFF91D2BE)
private val Gold = Color(0xFFE6C58B)
private val SoftText = Color(0xFFB7CAC8)
private val White = Color(0xFFF3F7F4)

private data class SoundItem(
    val id: String,
    val title: String,
    val subtitle: String,
    val icon: String,
    val category: String
)

private data class MoodMix(val title: String, val icon: String, val ids: List<String>)

private val categories = listOf("همه", "باران", "طوفان", "آب", "جنگل", "حیوانات", "انسان", "محیط", "نویز", "آرامش")

private val sounds = listOf(
    SoundItem("rain_drizzle", "نم‌نم باران", "بارش ریز و آرام روی زمین", "🌦️", "باران"),
    SoundItem("rain_soft", "باران ملایم", "بارش یکنواخت و لطیف", "🌧️", "باران"),
    SoundItem("rain_heavy", "باران شدید", "بارش پرحجم و پیوسته", "🌧️", "باران"),
    SoundItem("rain_roof", "باران روی سقف", "قطره‌های پراکنده روی سقف", "🏠", "باران"),
    SoundItem("rain_window", "باران پشت پنجره", "صدای قطره‌ها کنار شیشه", "🪟", "باران"),
    SoundItem("rain_tent", "باران روی چادر", "قطره‌های نزدیک و ریزش مداوم", "⛺", "باران"),
    SoundItem("rain_car", "باران داخل خودرو", "بارش یکنواخت و محصور", "🚗", "باران"),
    SoundItem("rain_forest", "باران در جنگل", "باران همراه با فضای جنگلی", "🌲", "باران"),
    SoundItem("thunder", "رعد و برق", "غرش‌های دور و نزدیک آسمان", "⚡", "طوفان"),
    SoundItem("storm_wind", "باد طوفانی", "وزش شدید و متغیر باد", "🌪️", "طوفان"),
    SoundItem("distant_thunder", "رعد دوردست", "غرش بم و کشیده در افق", "⛈️", "طوفان"),
    SoundItem("ocean", "موج دریا", "موج‌های آرام و رفت‌وبرگشتی", "🌊", "آب"),
    SoundItem("stream", "جویبار", "جریان نرم آب روی سنگ‌ها", "💧", "آب"),
    SoundItem("waterfall", "آبشار", "ریزش پیوسته و پرقدرت آب", "🏞️", "آب"),
    SoundItem("river", "رودخانه", "جریان گسترده آب", "🛶", "آب"),
    SoundItem("wind_trees", "باد میان درختان", "نسیم لابه‌لای برگ‌ها", "🍃", "جنگل"),
    SoundItem("forest_birds", "پرندگان جنگل", "آوازهای کوتاه و پراکنده", "🐦", "جنگل"),
    SoundItem("forest_ambience", "فضای جنگل", "باد، برگ و پرندگان", "🌳", "جنگل"),
    SoundItem("crickets", "جیرجیرک شب", "آواز پیوسته حشرات شب‌زی", "🦗", "حیوانات"),
    SoundItem("frogs", "قورباغه‌ها", "آوازهای کوتاه کنار آب", "🐸", "حیوانات"),
    SoundItem("cat_purr", "خرخر گربه", "صدای بم و لرزان شبیه خرخر", "🐈", "حیوانات"),
    SoundItem("dog_bark", "پارس سگ دوردست", "پارس‌های کوتاه با فاصله", "🐕", "حیوانات"),
    SoundItem("wolf_howl", "زوزه گرگ", "زوزه کشیده و دور", "🐺", "حیوانات"),
    SoundItem("fireplace", "آتش شومینه", "خش‌خش و ترق‌تروق هیزم", "🔥", "محیط"),
    SoundItem("cafe", "همهمه کافه", "گفت‌وگوی نامفهوم و فضای شلوغ", "☕", "محیط"),
    SoundItem("crowd", "همهمه جمعیت", "صدای جمعیت از فاصله دور", "👥", "انسان"),
    SoundItem("conversation", "همهمه گفت‌وگو", "چند گفت‌وگوی نامفهوم در پس‌زمینه", "🗣️", "انسان"),
    SoundItem("footsteps", "قدم‌زدن آرام", "قدم‌های منظم روی مسیر", "👣", "انسان"),
    SoundItem("applause", "تشویق جمعیت", "صدای کف‌زدن پراکنده", "👏", "انسان"),
    SoundItem("city", "فضای شهری", "زمزمه ممتد شهر و رفت‌وآمد", "🏙️", "محیط"),
    SoundItem("fan", "پنکه", "صدای یکنواخت دستگاه", "🌀", "محیط"),
    SoundItem("white_noise", "نویز سفید", "صدای یکنواخت با طیف گسترده", "〰️", "نویز"),
    SoundItem("pink_noise", "نویز صورتی", "صدای نرم‌تر با فرکانس‌های متعادل", "🌸", "نویز"),
    SoundItem("brown_noise", "نویز قهوه‌ای", "صدای بم و عمیق", "🟤", "نویز"),
    SoundItem("breathing", "تنفس آرام", "ریتم نرم دم و بازدم", "🌬️", "آرامش"),
    SoundItem("heartbeat", "ضربان قلب", "ضربان آرام و منظم", "❤️", "آرامش"),
    SoundItem("meditation", "طنین مراقبه", "صدای کشیده و ملایم برای تمرکز", "🧘", "آرامش")
)

private val moods = listOf(
    MoodMix("باران شب", "🌧️", listOf("rain_window", "rain_soft", "crickets")),
    MoodMix("خواب آرام", "🌙", listOf("rain_drizzle", "pink_noise", "breathing")),
    MoodMix("تمرکز", "🎧", listOf("brown_noise", "fan", "stream")),
    MoodMix("طوفان", "⛈️", listOf("rain_heavy", "thunder", "storm_wind")),
    MoodMix("جنگل سبز", "🌲", listOf("forest_ambience", "stream", "wind_trees")),
    MoodMix("آرامش دریا", "🌊", listOf("ocean", "wind_trees", "meditation")),
    MoodMix("انرژی صبح", "☀️", listOf("forest_birds", "stream", "waterfall"))
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(8, 26, 32)
        window.navigationBarColor = android.graphics.Color.rgb(8, 26, 32)
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 401)
        }
        setContent { AvaNatureTheme { AvaNatureApp() } }
    }
}

@Composable
private fun AvaNatureTheme(content: @Composable () -> Unit) {
    val colors = darkColorScheme(
        primary = Mint,
        secondary = Gold,
        background = Night,
        surface = Panel,
        onPrimary = Night,
        onSecondary = Night,
        onBackground = White,
        onSurface = White
    )
    MaterialTheme(colorScheme = colors, content = content)
}

@Composable
private fun AvaNatureApp() {
    val context = LocalContext.current
    var query by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("همه") }
    var onlyFavorites by remember { mutableStateOf(false) }
    val active = remember { mutableStateListOf<String>() }
    val favorites = remember { mutableStateListOf<String>() }
    var volume by remember { mutableFloatStateOf(0.78f) }
    var timerMinutes by remember { mutableStateOf(0) }
    var showTimer by remember { mutableStateOf(false) }
    var showAbout by remember { mutableStateOf(false) }

    val filtered = sounds.filter { item ->
        val matchesCategory = category == "همه" || item.category == category
        val matchesQuery = query.isBlank() || item.title.contains(query.trim(), ignoreCase = true) || item.subtitle.contains(query.trim(), ignoreCase = true)
        val matchesFavorites = !onlyFavorites || favorites.contains(item.id)
        matchesCategory && matchesQuery && matchesFavorites
    }

    CompositionLocalProvider(androidx.compose.ui.platform.LocalLayoutDirection provides LayoutDirection.Rtl) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(Brush.verticalGradient(listOf(Color(0xFF0D2A30), Night, Color(0xFF07151A))))
                .windowInsetsPadding(WindowInsets.statusBars)
                .windowInsetsPadding(WindowInsets.navigationBars)
                .padding(horizontal = 16.dp)
        ) {
            Header(onAbout = { showAbout = true })
            HeroCard(activeCount = active.size)
            Spacer(Modifier.height(12.dp))
            TextField(
                value = query,
                onValueChange = { query = it },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                placeholder = { Text("جست‌وجوی باران، جنگل، حیوانات…", color = SoftText) },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = "جست‌وجو", tint = Mint) },
                trailingIcon = if (query.isNotEmpty()) ({
                    TextButton(onClick = { query = "" }) { Text("پاک", color = Mint) }
                }) else null,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                keyboardActions = KeyboardActions(onSearch = { }),
                shape = RoundedCornerShape(18.dp),
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = Panel,
                    unfocusedContainerColor = Panel,
                    focusedIndicatorColor = Mint,
                    unfocusedIndicatorColor = Color.Transparent,
                    cursorColor = Mint,
                    focusedTextColor = White,
                    unfocusedTextColor = White
                )
            )
            Spacer(Modifier.height(14.dp))
            SectionTitle("ترکیب‌های آماده", "با یک لمس چند صدا را هم‌زمان پخش کن")
            LazyRow(horizontalArrangement = Arrangement.spacedBy(9.dp), modifier = Modifier.padding(top = 9.dp, bottom = 13.dp)) {
                items(moods) { mood ->
                    MoodChip(mood) {
                        active.clear()
                        active.addAll(mood.ids)
                        NatureSoundService.setPreset(context, mood.ids, volume)
                    }
                }
            }
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                SectionTitle("کتابخانه صدا", "${filtered.size} صدای قابل انتخاب")
                Spacer(Modifier.weight(1f))
                TextButton(onClick = {
                    onlyFavorites = !onlyFavorites
                    if (onlyFavorites) category = "همه"
                }) {
                    Icon(if (onlyFavorites) Icons.Default.Favorite else Icons.Default.FavoriteBorder, null, tint = Gold, modifier = Modifier.size(17.dp))
                    Text(if (onlyFavorites) "همه" else "علاقه‌مندی‌ها", color = Gold, fontSize = 11.sp)
                }
            }
            LazyRow(horizontalArrangement = Arrangement.spacedBy(7.dp), modifier = Modifier.padding(top = 8.dp, bottom = 10.dp)) {
                items(categories) { item ->
                    FilterChip(
                        selected = category == item && !onlyFavorites,
                        onClick = { category = item; onlyFavorites = false },
                        label = { Text(item, fontSize = 12.sp) }
                    )
                }
            }
            LazyColumn(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(filtered, key = { it.id }) { item ->
                    SoundCard(
                        item = item,
                        isActive = active.contains(item.id),
                        isFavorite = favorites.contains(item.id),
                        onToggle = {
                            if (active.contains(item.id)) active.remove(item.id) else active.add(item.id)
                            NatureSoundService.toggle(context, item.id)
                        },
                        onFavorite = {
                            if (favorites.contains(item.id)) favorites.remove(item.id) else favorites.add(item.id)
                        }
                    )
                }
                if (filtered.isEmpty()) {
                    item {
                        Text("موردی پیدا نشد. نام دیگری را جست‌وجو کن.", color = SoftText, modifier = Modifier.fillMaxWidth().padding(24.dp), textAlign = TextAlign.Center)
                    }
                }
                item { Spacer(Modifier.height(8.dp)) }
            }
            if (active.isNotEmpty()) {
                PlayerPanel(
                    activeCount = active.size,
                    volume = volume,
                    timerMinutes = timerMinutes,
                    onVolume = {
                        volume = it
                        NatureSoundService.setVolume(context, it)
                    },
                    onTimer = { showTimer = true },
                    onStop = {
                        active.clear()
                        timerMinutes = 0
                        NatureSoundService.stopAll(context)
                    }
                )
            }
        }
    }

    if (showTimer) {
        TimerDialog(
            selected = timerMinutes,
            onDismiss = { showTimer = false },
            onSelect = {
                timerMinutes = it
                NatureSoundService.setTimer(context, it)
                showTimer = false
            }
        )
    }
    if (showAbout) {
        AlertDialog(
            onDismissRequest = { showAbout = false },
            containerColor = Panel,
            title = { Text("درباره آواطبیعت", color = White, fontWeight = FontWeight.Bold) },
            text = {
                Text(
                    "آواطبیعت یک میکسر آفلاین صداهای محیطی است. صداها در همین گوشی به‌صورت دیجیتالی تولید و ترکیب می‌شوند؛ بنابراین افکت‌های طبیعت و حیوانات بازسازی صوتی هستند، نه فایل ضبط‌شده واقعی. برنامه برای پخش پس‌زمینه و تایمر خواب طراحی شده است.",
                    color = SoftText, lineHeight = 23.sp
                )
            },
            confirmButton = { TextButton(onClick = { showAbout = false }) { Text("متوجه شدم", color = Mint) } }
        )
    }
}

@Composable
private fun Header(onAbout: () -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(top = 8.dp, bottom = 13.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier.size(47.dp).clip(RoundedCornerShape(16.dp)).background(Brush.linearGradient(listOf(Color(0xFF2B7468), Color(0xFF143D42)))),
            contentAlignment = Alignment.Center
        ) { Text("🌿", fontSize = 25.sp) }
        Column(modifier = Modifier.padding(start = 11.dp)) {
            Text("آواطبیعت", color = White, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold)
            Text("صدای آرامش، از دل طبیعت", color = SoftText, fontSize = 11.sp)
        }
        Spacer(Modifier.weight(1f))
        IconButton(onClick = onAbout) {
            Icon(Icons.Default.Info, contentDescription = "درباره برنامه", tint = Gold)
        }
    }
}

@Composable
private fun HeroCard(activeCount: Int) {
    Card(
        shape = RoundedCornerShape(25.dp),
        colors = CardDefaults.cardColors(containerColor = Color.Transparent),
        modifier = Modifier.fillMaxWidth()
    ) {
        Box(
            modifier = Modifier.background(Brush.linearGradient(listOf(Color(0xFF22564F), Color(0xFF14343B), Color(0xFF10242F)))).padding(horizontal = 18.dp, vertical = 16.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("فضای دلخواهت را بساز", color = White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(5.dp))
                    Text("باران، رعدوبرق، جنگل و صدها ترکیب شنیداری", color = Color(0xFFD3E4DE), fontSize = 11.sp)
                    Spacer(Modifier.height(10.dp))
                    Surface(color = Color(0x3328B39B), shape = RoundedCornerShape(30.dp)) {
                        Text(if (activeCount == 0) "آفلاین • آماده پخش" else "$activeCount لایه صوتی فعال", color = Mint, fontSize = 10.sp, modifier = Modifier.padding(horizontal = 11.dp, vertical = 6.dp))
                    }
                }
                Text("🌧️\n🌲", fontSize = 38.sp, lineHeight = 42.sp, textAlign = TextAlign.Center)
            }
        }
    }
}

@Composable
private fun SectionTitle(title: String, subtitle: String) {
    Column {
        Text(title, color = White, fontSize = 15.sp, fontWeight = FontWeight.Bold)
        Text(subtitle, color = SoftText, fontSize = 10.sp)
    }
}

@Composable
private fun MoodChip(mood: MoodMix, onClick: () -> Unit) {
    Surface(
        modifier = Modifier.clip(RoundedCornerShape(16.dp)).clickable(onClick = onClick),
        shape = RoundedCornerShape(16.dp),
        color = Color(0xFF18383D),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF2C5554))
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp)) {
            Text(mood.icon, fontSize = 18.sp)
            Text(mood.title, color = White, fontSize = 12.sp, modifier = Modifier.padding(start = 7.dp), fontWeight = FontWeight.SemiBold)
        }
    }
}

@Composable
private fun SoundCard(item: SoundItem, isActive: Boolean, isFavorite: Boolean, onToggle: () -> Unit, onFavorite: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onToggle),
        shape = RoundedCornerShape(19.dp),
        colors = CardDefaults.cardColors(containerColor = if (isActive) PanelActive else Panel),
        border = if (isActive) androidx.compose.foundation.BorderStroke(1.dp, Mint.copy(alpha = 0.55f)) else null
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier.size(43.dp).clip(RoundedCornerShape(14.dp)).background(if (isActive) Color(0xFF285D54) else Color(0xFF1C3A3F)),
                contentAlignment = Alignment.Center
            ) { Text(item.icon, fontSize = 23.sp) }
            Column(modifier = Modifier.weight(1f).padding(horizontal = 11.dp)) {
                Text(item.title, color = White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                Text(item.subtitle, color = SoftText, fontSize = 10.sp, maxLines = 1)
            }
            IconButton(onClick = onFavorite, modifier = Modifier.size(34.dp)) {
                Icon(if (isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder, contentDescription = "علاقه‌مندی", tint = if (isFavorite) Gold else Color(0xFF77928F), modifier = Modifier.size(18.dp))
            }
            Surface(
                modifier = Modifier.size(35.dp).clip(CircleShape).clickable(onClick = onToggle),
                shape = CircleShape,
                color = if (isActive) Mint else Color(0xFF25474A)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(if (isActive) Icons.Default.Pause else Icons.Default.PlayArrow, contentDescription = if (isActive) "توقف" else "پخش", tint = if (isActive) Night else Mint, modifier = Modifier.size(21.dp))
                }
            }
        }
    }
}

@Composable
private fun PlayerPanel(
    activeCount: Int,
    volume: Float,
    timerMinutes: Int,
    onVolume: (Float) -> Unit,
    onTimer: () -> Unit,
    onStop: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth().padding(top = 8.dp, bottom = 8.dp),
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF1A393D)),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF37625B))
    ) {
        Column(modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(modifier = Modifier.size(8.dp).clip(CircleShape).background(Mint))
                Text("در حال پخش  •  $activeCount صدا", color = White, fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 8.dp))
                Spacer(Modifier.weight(1f))
                TextButton(onClick = onTimer, contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 7.dp, vertical = 2.dp)) {
                    Icon(Icons.Default.AccessTime, null, tint = Gold, modifier = Modifier.size(16.dp))
                    Text(if (timerMinutes == 0) "تایمر" else "$timerMinutes دقیقه", color = Gold, fontSize = 11.sp)
                }
                IconButton(onClick = onStop, modifier = Modifier.size(32.dp)) {
                    Icon(Icons.Default.Stop, contentDescription = "توقف همه", tint = Color(0xFFFFB4A9))
                }
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("صدا", color = SoftText, fontSize = 10.sp)
                Slider(value = volume, onValueChange = onVolume, modifier = Modifier.weight(1f).padding(horizontal = 7.dp))
                Text("${(volume * 100).roundToInt()}٪", color = White, fontSize = 10.sp)
            }
        }
    }
}

@Composable
private fun TimerDialog(selected: Int, onDismiss: () -> Unit, onSelect: (Int) -> Unit) {
    val options = listOf(0, 15, 30, 45, 60, 90, 120)
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Panel,
        title = { Text("تایمر خواب", color = White, fontWeight = FontWeight.Bold) },
        text = {
            Column {
                Text("پخش صداها پس از چه مدتی متوقف شود؟", color = SoftText, fontSize = 13.sp)
                Spacer(Modifier.height(10.dp))
                options.chunked(3).forEach { rowOptions ->
                    Row(horizontalArrangement = Arrangement.spacedBy(7.dp), modifier = Modifier.fillMaxWidth()) {
                        rowOptions.forEach { option ->
                            FilterChip(
                                selected = selected == option,
                                onClick = { onSelect(option) },
                                label = { Text(if (option == 0) "خاموش" else "$option دقیقه", fontSize = 11.sp) },
                                modifier = Modifier.weight(1f)
                            )
                        }
                        repeat(3 - rowOptions.size) { Spacer(Modifier.weight(1f)) }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("بستن", color = Mint) } }
    )
}

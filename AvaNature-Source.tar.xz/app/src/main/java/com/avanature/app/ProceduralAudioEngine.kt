package com.avanature.app

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.math.tanh
import kotlin.random.Random

/** Small offline audio synthesizer. Every sound is generated locally; no media is streamed. */
class ProceduralAudioEngine {
    @Volatile
    var masterVolume: Float = 0.78f

    @Volatile
    private var running = false

    private val lock = Any()
    private val voices = linkedMapOf<String, SoundVoice>()
    private var worker: Thread? = null

    fun add(id: String) {
        synchronized(lock) { if (!voices.containsKey(id)) voices[id] = SoundVoice(id) }
        start()
    }

    fun remove(id: String) {
        synchronized(lock) { voices.remove(id) }
    }

    fun replace(ids: List<String>) {
        synchronized(lock) {
            voices.clear()
            ids.distinct().forEach { voices[it] = SoundVoice(it) }
        }
    }

    fun clear() = synchronized(lock) { voices.clear() }

    @Synchronized
    fun start() {
        if (worker?.isAlive == true) return
        running = true
        worker = Thread({ renderLoop() }, "AvaNature-Audio").apply {
            isDaemon = true
            start()
        }
    }

    @Synchronized
    fun stop() {
        running = false
        try { worker?.join(700) } catch (_: InterruptedException) { Thread.currentThread().interrupt() }
        worker = null
    }

    private fun renderLoop() {
        val sampleRate = 22_050
        val channelMask = AudioFormat.CHANNEL_OUT_MONO
        val minBytes = AudioTrack.getMinBufferSize(sampleRate, channelMask, AudioFormat.ENCODING_PCM_16BIT)
        val audioTrack = try {
            AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(sampleRate)
                        .setChannelMask(channelMask)
                        .build()
                )
                .setTransferMode(AudioTrack.MODE_STREAM)
                .setBufferSizeInBytes(max(minBytes, 4096) * 2)
                .build()
        } catch (_: Exception) {
            return
        }

        val frames = 512
        val buffer = ShortArray(frames)
        var clock = 0.0
        try {
            audioTrack.play()
            while (running) {
                val snapshot = synchronized(lock) { voices.values.toList() }
                if (snapshot.isEmpty()) {
                    Thread.sleep(35)
                    continue
                }
                val gain = masterVolume.coerceIn(0f, 1f).toDouble() / max(1.0, sqrt(snapshot.size.toDouble()))
                for (i in 0 until frames) {
                    var mixed = 0.0
                    snapshot.forEach { mixed += it.next(clock, sampleRate) }
                    val shaped = tanh(mixed * gain * 2.0) * 0.88
                    buffer[i] = (shaped * 32767.0).toInt().coerceIn(-32768, 32767).toShort()
                    clock += 1.0 / sampleRate
                }
                val written = audioTrack.write(buffer, 0, buffer.size, AudioTrack.WRITE_BLOCKING)
                if (written < 0) break
            }
        } catch (_: InterruptedException) {
            Thread.currentThread().interrupt()
        } catch (_: Exception) {
        } finally {
            try { audioTrack.pause() } catch (_: Exception) { }
            try { audioTrack.flush() } catch (_: Exception) { }
            try { audioTrack.stop() } catch (_: Exception) { }
            audioTrack.release()
        }
    }

    private class SoundVoice(private val id: String) {
        private val random = Random(System.nanoTime() xor id.hashCode().toLong())
        private var low = 0.0
        private var low2 = 0.0
        private var brown = 0.0
        private var phase = 0.0
        private var eventStart = -100.0
        private var eventEnd = 0.0
        private var nextEvent = random.nextDouble(0.4, 3.2)
        private var eventFrequency = random.nextDouble(180.0, 480.0)
        private var eventSweep = random.nextDouble(500.0, 1700.0)
        private var eventStrength = random.nextDouble(0.2, 0.65)
        private var dropEnvelope = 0.0
        private var previousNoise = 0.0

        private fun noise(): Double = random.nextDouble(-1.0, 1.0)

        private fun chirp(time: Double, gapMin: Double, gapMax: Double, base: Double, sweep: Double, duration: Double): Double {
            if (time >= nextEvent) {
                eventStart = time
                eventEnd = time + duration * random.nextDouble(0.7, 1.4)
                eventFrequency = base * random.nextDouble(0.78, 1.22)
                eventSweep = sweep * random.nextDouble(0.65, 1.3)
                eventStrength = random.nextDouble(0.18, 0.55)
                nextEvent = time + random.nextDouble(gapMin, gapMax)
            }
            val age = time - eventStart
            if (age < 0.0 || time > eventEnd) return 0.0
            val span = max(0.025, eventEnd - eventStart)
            val p = (age / span).coerceIn(0.0, 1.0)
            val envelope = sin(PI * p).pow(1.6)
            val frequency = eventFrequency + eventSweep * p
            phase += 2.0 * PI * frequency / 22_050.0
            return sin(phase) * envelope * eventStrength
        }

        private fun rain(time: Double, intensity: Double): Double {
            val n = noise()
            low += 0.028 * (n - low)
            low2 += 0.003 * (n - low2)
            if (random.nextDouble() < 0.0007 * intensity) dropEnvelope = random.nextDouble(0.25, 0.9)
            dropEnvelope *= 0.99935
            val droplets = (n * dropEnvelope * 0.38) + (noise() * dropEnvelope * 0.12)
            val patter = n * 0.12 + low * 0.42 + low2 * 0.28
            return (patter + droplets) * (0.32 + 0.18 * intensity)
        }

        private fun thunder(time: Double, intensity: Double): Double {
            if (time >= nextEvent) {
                eventStart = time
                eventStrength = random.nextDouble(0.45, 0.95) * intensity
                eventEnd = time + random.nextDouble(4.5, 9.0)
                nextEvent = time + random.nextDouble(10.0, 22.0)
            }
            val n = noise()
            low += 0.0017 * (n - low)
            val age = time - eventStart
            val envelope = if (age in 0.0..12.0) exp(-age / 3.1) * (0.55 + 0.45 * abs(sin(age * 2.2))) else 0.0
            val rumble = sin(2.0 * PI * (38.0 + 5.0 * sin(time * 0.17)) * time) * 0.4
            return (low * 1.7 + rumble) * envelope * eventStrength + low * 0.025
        }

        fun next(time: Double, sampleRate: Int): Double {
            val n = noise()
            return when (id) {
                "rain_drizzle" -> rain(time, 0.48)
                "rain_soft", "rain_window", "rain_car", "rain_forest" -> rain(time, 0.78)
                "rain_heavy", "rain_tent" -> rain(time, 1.55)
                "rain_roof" -> {
                    if (random.nextDouble() < 0.0009) dropEnvelope = random.nextDouble(0.45, 1.0)
                    dropEnvelope *= 0.9991
                    low += 0.02 * (n - low)
                    low * 0.11 + n * 0.035 + sin(time * 17.0) * dropEnvelope * 0.16
                }
                "thunder" -> thunder(time, 1.0) + rain(time, 1.0) * 0.35
                "distant_thunder" -> thunder(time, 0.55)
                "storm_wind" -> {
                    low += 0.002 * (n - low)
                    val swell = 0.35 + 0.65 * (0.5 + 0.5 * sin(time * 0.23 + sin(time * 0.047)))
                    (low * 1.45 + n * 0.09) * swell * 0.22
                }
                "ocean" -> {
                    low += 0.018 * (n - low)
                    low2 += 0.002 * (n - low2)
                    val swell = 0.12 + 0.88 * (0.5 + 0.5 * sin(2.0 * PI * time / 10.5 - 0.8)).pow(2.2)
                    (low * 0.65 + low2 * 0.35 + n * 0.11) * swell * 0.42
                }
                "stream", "river" -> {
                    low += 0.035 * (n - low)
                    low2 += 0.009 * (n - low2)
                    (n * 0.13 + low * 0.35 + low2 * 0.3 + sin(time * 7.0 + low * 5.0) * 0.025) * 0.52
                }
                "waterfall" -> {
                    low += 0.018 * (n - low)
                    (n * 0.18 + low * 0.25 + noise() * 0.08) * 0.55
                }
                "wind_trees", "forest_ambience" -> {
                    low += 0.0028 * (n - low)
                    val breeze = 0.28 + 0.72 * (0.5 + 0.5 * sin(time * 0.18 + sin(time * 0.037)))
                    val leaves = n * 0.05 + noise() * 0.025
                    low * breeze * 0.27 + leaves + if (id == "forest_ambience") chirp(time, 1.0, 4.0, 1900.0, 1300.0, 0.18) * 0.45 else 0.0
                }
                "forest_birds" -> chirp(time, 0.28, 1.65, 2100.0, 1550.0, 0.13) + chirp(time + 0.6, 1.1, 3.2, 1450.0, 850.0, 0.21) * 0.55
                "crickets" -> {
                    val pulse = (0.5 + 0.5 * sin(2.0 * PI * 5.0 * time)).pow(7.0)
                    val carrier = sin(2.0 * PI * 3900.0 * time + 0.3 * sin(time * 8.0))
                    (carrier * pulse * 0.15) + chirp(time, 2.5, 6.0, 3200.0, 500.0, 0.08) * 0.18
                }
                "frogs" -> chirp(time, 1.1, 3.8, 410.0, -80.0, 0.3) * (0.8 + 0.2 * sin(time * 0.3))
                "cat_purr" -> {
                    val motor = sin(2.0 * PI * 27.0 * time) * (0.5 + 0.5 * sin(2.0 * PI * 3.3 * time))
                    low += 0.015 * (n - low)
                    motor * 0.12 + low * 0.07
                }
                "dog_bark" -> {
                    if (time >= nextEvent) {
                        eventStart = time
                        eventEnd = time + random.nextDouble(0.16, 0.34)
                        eventStrength = random.nextDouble(0.35, 0.75)
                        nextEvent = time + random.nextDouble(3.0, 7.0)
                    }
                    val age = time - eventStart
                    if (age in 0.0..0.6) {
                        low += 0.04 * (n - low)
                        (sin(2.0 * PI * (115.0 + 45.0 * sin(age * 16.0)) * age) * 0.5 + low * 0.8) * exp(-age * 8.5) * eventStrength
                    } else 0.0
                }
                "wolf_howl" -> {
                    if (time >= nextEvent) {
                        eventStart = time
                        eventEnd = time + random.nextDouble(3.2, 5.2)
                        eventStrength = random.nextDouble(0.24, 0.46)
                        nextEvent = time + random.nextDouble(13.0, 21.0)
                    }
                    val age = time - eventStart
                    if (age in 0.0..6.0) {
                        val span = max(0.1, eventEnd - eventStart)
                        val p = (age / span).coerceIn(0.0, 1.0)
                        val env = sin(PI * p).pow(0.7)
                        val f = 390.0 + 230.0 * sin(p * PI * 0.72)
                        (sin(2.0 * PI * f * age) + 0.35 * sin(2.0 * PI * f * 2.02 * age)) * env * eventStrength
                    } else 0.0
                }
                "fireplace" -> {
                    if (random.nextDouble() < 0.00018) dropEnvelope = random.nextDouble(0.5, 1.0)
                    dropEnvelope *= 0.9985
                    low += 0.055 * (n - low)
                    low * 0.16 + n * 0.035 + dropEnvelope * sin(time * 190.0) * 0.19
                }
                "cafe", "crowd", "city", "conversation" -> {
                    low += 0.006 * (n - low)
                    low2 += 0.0008 * (n - low2)
                    val murmur = 0.5 + 0.5 * sin(time * (if (id == "cafe") 0.72 else 0.31) + sin(time * 0.11))
                    val distant = sin(time * 2.7) * 0.025 + sin(time * 4.3 + 0.8) * 0.018
                    val speechColor = if (id == "conversation") (sin(time * 19.0) * 0.035 + sin(time * 31.0 + 1.2) * 0.022) else 0.0
                    (low * 0.5 + low2 * 0.35 + n * 0.055 + distant + speechColor) * (0.24 + murmur * 0.24)
                }
                "footsteps" -> {
                    if (time >= nextEvent) {
                        eventStart = time
                        eventEnd = time + random.nextDouble(0.12, 0.23)
                        eventStrength = random.nextDouble(0.22, 0.48)
                        nextEvent = time + random.nextDouble(0.48, 0.78)
                    }
                    val age = time - eventStart
                    if (age in 0.0..0.4) {
                        low += 0.05 * (n - low)
                        (low * 0.55 + noise() * 0.18) * exp(-age * 15.0) * eventStrength
                    } else 0.0
                }
                "applause" -> {
                    if (random.nextDouble() < 0.00055) dropEnvelope = random.nextDouble(0.35, 1.0)
                    dropEnvelope *= 0.997
                    low += 0.06 * (n - low)
                    (n * 0.12 + low * 0.18) * dropEnvelope * 0.75
                }
                "fan" -> {
                    low += 0.014 * (n - low)
                    (low * 0.4 + n * 0.035 + sin(2.0 * PI * 55.0 * time) * 0.06 + sin(2.0 * PI * 110.0 * time) * 0.025)
                }
                "white_noise" -> n * 0.18
                "pink_noise" -> {
                    low += 0.02 * (n - low)
                    low2 += 0.002 * (n - low2)
                    (n * 0.035 + low * 0.12 + low2 * 0.14)
                }
                "brown_noise" -> {
                    brown = (brown + n * 0.012).coerceIn(-1.7, 1.7)
                    brown * 0.18
                }
                "breathing" -> {
                    val cycle = (time % 6.8) / 6.8
                    val envelope = if (cycle < 0.48) sin(PI * cycle / 0.48) else sin(PI * (1.0 - cycle) / 0.52)
                    low += 0.007 * (n - low)
                    (low * 0.4 + n * 0.025) * envelope.coerceAtLeast(0.0) * 0.34
                }
                "heartbeat" -> {
                    val beatPhase = time % 1.04
                    val beat1 = exp(-((beatPhase - 0.08) / 0.045).pow(2.0))
                    val beat2 = exp(-((beatPhase - 0.24) / 0.055).pow(2.0)) * 0.68
                    (sin(2.0 * PI * 54.0 * time) * (beat1 + beat2)) * 0.34
                }
                "meditation" -> {
                    val swell = 0.65 + 0.35 * sin(2.0 * PI * 0.08 * time)
                    (sin(2.0 * PI * 174.61 * time) * 0.075 + sin(2.0 * PI * 261.63 * time) * 0.043 + sin(2.0 * PI * 349.23 * time) * 0.022) * swell
                }
                else -> {
                    // Safe fallback for an unknown library ID.
                    low += 0.02 * (n - low)
                    low * 0.1
                }
            }
        }
    }
}

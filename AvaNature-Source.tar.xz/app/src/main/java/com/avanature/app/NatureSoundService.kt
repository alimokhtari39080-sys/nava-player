package com.avanature.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager

class NatureSoundService : Service() {
    private lateinit var engine: ProceduralAudioEngine
    private val activeIds = linkedSetOf<String>()
    private val handler = Handler(Looper.getMainLooper())
    private var timerRunnable: Runnable? = null
    private var wakeLock: PowerManager.WakeLock? = null

    override fun onCreate() {
        super.onCreate()
        engine = ProceduralAudioEngine()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_TOGGLE -> {
                val id = intent.getStringExtra(EXTRA_ID) ?: return START_NOT_STICKY
                if (activeIds.contains(id)) {
                    activeIds.remove(id)
                    engine.remove(id)
                } else {
                    activeIds.add(id)
                    engine.add(id)
                }
                persistActive()
                syncPlayback()
            }
            ACTION_PRESET -> {
                val ids = intent.getStringArrayListExtra(EXTRA_IDS)?.distinct().orEmpty()
                activeIds.clear()
                activeIds.addAll(ids)
                engine.replace(ids)
                val requestedVolume = intent.getFloatExtra(EXTRA_VOLUME, -1f)
                if (requestedVolume >= 0f) engine.masterVolume = requestedVolume.coerceIn(0f, 1f)
                persistActive()
                syncPlayback()
            }
            ACTION_STOP -> {
                activeIds.clear()
                engine.clear()
                persistActive()
                cancelTimer()
                stopPlayback()
            }
            ACTION_VOLUME -> {
                engine.masterVolume = intent.getFloatExtra(EXTRA_VOLUME, 0.78f).coerceIn(0f, 1f)
                getSharedPreferences(PREFS, MODE_PRIVATE).edit().putFloat(KEY_VOLUME, engine.masterVolume).apply()
            }
            ACTION_TIMER -> {
                val minutes = intent.getIntExtra(EXTRA_MINUTES, 0)
                setTimerInternal(minutes)
            }
            else -> return START_NOT_STICKY
        }
        return START_NOT_STICKY
    }

    private fun syncPlayback() {
        if (activeIds.isNotEmpty()) {
            ensureForeground()
            acquireWakeLock()
            engine.start()
            updateNotification()
        } else {
            stopPlayback()
        }
    }

    private fun ensureForeground() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForeground(NOTIFICATION_ID, buildNotification())
        }
    }

    private fun updateNotification() {
        val manager = getSystemService(NotificationManager::class.java)
        manager.notify(NOTIFICATION_ID, buildNotification())
    }

    private fun buildNotification(): Notification {
        val openIntent = Intent(this, MainActivity::class.java)
        val openPending = PendingIntent.getActivity(
            this, 10, openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val stopIntent = Intent(this, NatureSoundService::class.java).setAction(ACTION_STOP)
        val stopPending = PendingIntent.getService(
            this, 11, stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return Notification.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle("آواطبیعت")
            .setContentText("${activeIds.size} لایه صوتی در حال پخش")
            .setContentIntent(openPending)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .addAction(android.R.drawable.ic_media_pause, "توقف همه", stopPending)
            .build()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "پخش صداهای آواطبیعت",
                NotificationManager.IMPORTANCE_LOW
            ).apply { description = "کنترل پخش صداهای محیطی در پس‌زمینه" }
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun acquireWakeLock() {
        if (wakeLock?.isHeld == true) return
        val powerManager = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = powerManager.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "AvaNature::AudioPlayback").apply {
            setReferenceCounted(false)
            acquire()
        }
    }

    private fun releaseWakeLock() {
        try {
            if (wakeLock?.isHeld == true) wakeLock?.release()
        } catch (_: RuntimeException) {
        }
        wakeLock = null
    }

    private fun setTimerInternal(minutes: Int) {
        cancelTimer()
        if (minutes <= 0) return
        val task = Runnable {
            activeIds.clear()
            engine.clear()
            persistActive()
            stopPlayback()
        }
        timerRunnable = task
        handler.postDelayed(task, minutes * 60_000L)
    }

    private fun cancelTimer() {
        timerRunnable?.let(handler::removeCallbacks)
        timerRunnable = null
    }

    private fun persistActive() {
        getSharedPreferences(PREFS, MODE_PRIVATE).edit()
            .putStringSet(KEY_ACTIVE, activeIds.toSet())
            .apply()
    }

    @Suppress("DEPRECATION")
    private fun stopPlayback() {
        engine.stop()
        releaseWakeLock()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) stopForeground(STOP_FOREGROUND_REMOVE)
        else stopForeground(true)
        stopSelf()
    }

    override fun onDestroy() {
        cancelTimer()
        engine.stop()
        releaseWakeLock()
        activeIds.clear()
        persistActive()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        private const val CHANNEL_ID = "avanature_sound_playback"
        private const val NOTIFICATION_ID = 7321
        const val PREFS = "avanature_settings"
        const val KEY_VOLUME = "master_volume"
        const val KEY_ACTIVE = "active_sound_ids"

        private const val EXTRA_ID = "sound_id"
        private const val EXTRA_IDS = "sound_ids"
        private const val EXTRA_VOLUME = "volume"
        private const val EXTRA_MINUTES = "minutes"

        const val ACTION_TOGGLE = "com.avanature.app.TOGGLE"
        const val ACTION_PRESET = "com.avanature.app.PRESET"
        const val ACTION_STOP = "com.avanature.app.STOP"
        const val ACTION_VOLUME = "com.avanature.app.VOLUME"
        const val ACTION_TIMER = "com.avanature.app.TIMER"

        private fun dispatch(context: Context, intent: Intent) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) context.startForegroundService(intent)
            else context.startService(intent)
        }

        fun toggle(context: Context, id: String) {
            dispatch(context, Intent(context, NatureSoundService::class.java).setAction(ACTION_TOGGLE).putExtra(EXTRA_ID, id))
        }

        fun setPreset(context: Context, ids: List<String>, volume: Float) {
            dispatch(
                context,
                Intent(context, NatureSoundService::class.java)
                    .setAction(ACTION_PRESET)
                    .putStringArrayListExtra(EXTRA_IDS, ArrayList(ids))
                    .putExtra(EXTRA_VOLUME, volume)
            )
        }

        fun stopAll(context: Context) {
            dispatch(context, Intent(context, NatureSoundService::class.java).setAction(ACTION_STOP))
        }

        fun setVolume(context: Context, volume: Float) {
            dispatch(context, Intent(context, NatureSoundService::class.java).setAction(ACTION_VOLUME).putExtra(EXTRA_VOLUME, volume))
        }

        fun setTimer(context: Context, minutes: Int) {
            dispatch(context, Intent(context, NatureSoundService::class.java).setAction(ACTION_TIMER).putExtra(EXTRA_MINUTES, minutes))
        }
    }
}

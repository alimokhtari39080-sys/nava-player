# آواطبیعت | AvaNature

A standalone Android soundscape app project. It lives in `nature-sounds/` when included in the NAVA Player repository, so it does not change NAVA's package name or app module.

## Features
- Persian-first interface with searchable sound library and category filters.
- Rain variations, thunder, wind, water, forests, birds, insects, animal-inspired effects, ambience, human crowd/cafe murmur, noise colors and relaxation tones.
- One-tap mood mixes for sleep, calm, focus, storms, forests and nature energy.
- Multiple simultaneous layers, master volume, sleep timer and background playback notification.
- Offline operation; no account, network permission or external service needed.

## Audio note
Version 1 generates soundscapes locally with procedural digital audio synthesis. These are sound-effect recreations, not field recordings or authentic animal/human recordings. The interface labels the ambience accordingly.

## Build
From this directory, run `gradle :app:assembleDebug` with Android SDK platform 35 and Java 17.
The APK is written to `app/build/outputs/apk/debug/app-debug.apk`.
